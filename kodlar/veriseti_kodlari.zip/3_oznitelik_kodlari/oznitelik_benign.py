#!/usr/bin/env python3
import os
import json
import concurrent.futures
import traceback
import multiprocessing
import sys
import time

# --------------------------------------------------------
# 🔇 LOG SUSTURUCU
# --------------------------------------------------------
try:
    from loguru import logger
    logger.remove()
    logger.add(sys.stderr, level="CRITICAL")
except ImportError:
    pass

import logging
logging.getLogger("androguard").setLevel(logging.CRITICAL)

from androguard.misc import AnalyzeAPK

# ========================================================
# ⚙️ AYARLAR
# ========================================================
APK_DIR = "/home/azureuser/dataset/APKlar/Benign"
ROOTS = ["/home/azureuser/dataset/Benign_result"]

MAX_WORKERS = 1
TIMEOUT_SECONDS = 600 

# ========================================================
# 🎯 HEDEF API LİSTESİ
# ========================================================
TARGET_APIS = {
    "camera": [
        "Landroid/hardware/Camera;->open", 
        "Landroid/hardware/camera2/CameraManager;->openCamera"
    ],
    "microphone": [
        "Landroid/media/MediaRecorder;->start", 
        "Landroid/media/AudioRecord;->startRecording"
    ],
    "location": [
        "Landroid/location/LocationManager;->requestLocationUpdates", 
        "Lcom/google/android/gms/location/FusedLocationProviderClient;->requestLocationUpdates"
    ],
    "torch": [
        "Landroid/hardware/camera2/CameraManager;->setTorchMode",
        "Landroid/hardware/Camera$Parameters;->setFlashMode"
    ],
    "telephony_ops": [
        "Landroid/telephony/SmsManager;->sendTextMessage",
        "Landroid/telephony/TelephonyManager;->getAllCellInfo"
    ],
    "system_commands": [
        "Ljava/lang/Runtime;->exec", 
        "Ljava/lang/ProcessBuilder;->start"
    ],
    "webview_interop": [
        "Landroid/webkit/WebView;->addJavascriptInterface",
        "Landroid/webkit/WebView;->loadUrl"
    ],
    "content_access": [
        "Landroid/content/ContentResolver;->query",
        "Landroid/content/ContentProvider;->insert"
    ],
    "audio_control": [ 
        "Landroid/media/AudioManager;->setRingerMode",
        "Landroid/media/AudioManager;->setStreamVolume"
    ],
    "vibration": [ 
        "Landroid/os/Vibrator;->vibrate"
    ],
    "network_io": [
        "Ljava/net/HttpURLConnection;->connect",
        "Ljava/net/Socket;->connect",
        "Lokhttp3/Call;->execute",
        "Lokhttp3/Call;->enqueue"
    ],
    "scheduling_apis": [
        "Landroid/app/AlarmManager;->set",
        "Landroid/app/job/JobScheduler;->schedule",
        "Landroid/os/Handler;->postDelayed"
    ],
    "dynamic_code": [
        "Ljava/lang/System;->loadLibrary", 
        "Ldalvik/system/DexClassLoader;",
        "Ljava/lang/Class;->forName",       
        "Ljava/lang/reflect/Method;->invoke" 
    ]
}

# ========================================================
# 🧠 YARDIMCI FONKSİYONLAR
# ========================================================

def normalize_class_name(name):
    if not name: return ""
    try:
        name = str(name)
        if not name.startswith("L") and "/" in name:
            name = "L" + name
        if not name.endswith(";"):
            name = name + ";"
        return name
    except:
        return ""

def get_method_details_safe(method_obj):
    m_name = ""
    m_class = ""
    try:
        if hasattr(method_obj, "get_name"):
            m_name = method_obj.get_name()
        elif hasattr(method_obj, "name"):
            m_name = str(method_obj.name)
            
        if hasattr(method_obj, "get_class_name"):
            m_class = str(method_obj.get_class_name())
        elif hasattr(method_obj, "class_name"):
            m_class = str(method_obj.class_name)
            
        if not m_name and hasattr(method_obj, "get_method"):
            real = method_obj.get_method()
            if hasattr(real, "get_name"): m_name = real.get_name()
            if hasattr(real, "get_class_name"): m_class = str(real.get_class_name())
            
    except: pass
    return m_name, normalize_class_name(m_class)

def get_inheritance_context(dx, class_name):
    current_class = normalize_class_name(class_name)
    depth = 0
    max_depth = 10 
    while depth < max_depth:
        if "Landroid/app/Service;" in current_class or "Landroid/app/IntentService;" in current_class:
            return "in_service"
        if "Landroid/app/Activity;" in current_class or "Landroidx/appcompat/app/AppCompatActivity;" in current_class:
            return "in_activity"
        if "Landroid/content/BroadcastReceiver;" in current_class:
            return "in_receiver"
        if "Landroid/content/ContentProvider;" in current_class:
            return "in_provider"
        if current_class.startswith("Ljava/") or not current_class:
            return "unknown"
        try:
            c_def = dx.get_class_analysis(current_class)
            if c_def and hasattr(c_def, "get_extends"):
                superclass = c_def.get_extends()
                if superclass and superclass != current_class:
                    current_class = normalize_class_name(superclass)
                    depth += 1
                else: break
            else: break
        except: break
    return "unknown"

# ========================================================
# 🔥 ANALİZ MOTORU (MANUEL FİLTRASYON MODU)
# ========================================================

def analyze_apk_worker(task_tuple):
    json_path, apk_path = task_tuple
    
    results = {
        "api_inventory": {k: 0 for k in TARGET_APIS.keys()},
        "execution_context": {"in_service": 0, "in_receiver": 0, "in_activity": 0, "in_provider": 0, "unknown": 0},
        "scheduling_mechanisms": {"alarm_manager": 0, "handler_loop": 0, "job_scheduler": 0},
        "trigger_types": {"auto_triggered": 0, "user_triggered": 0},
        "dynamic_features": {"jni_usage": 0, "dynamic_loading": 0, "reflection": 0}
    }

    try:
        a, d, dx = AnalyzeAPK(apk_path)
        if not dx: return f"[WARN] {os.path.basename(apk_path)}: DEX yok."

        seen_calls = set()
        total_hits = 0
        
        # DEĞİŞİKLİK BURADA: find_methods() yerine get_methods() kullanıp
        # manuel olarak "Bu external mı?" diye kontrol ediyoruz.
        for method in dx.get_methods():
            
            # 1. Sadece Internal (Uygulamanın kendi kodu) olanlara bak
            # is_external() fonksiyonu varsa kullan, yoksa varsayalım ki internal
            if hasattr(method, "is_external"):
                if method.is_external():
                    continue # Dış kütüphane metodlarını atla, biz kodun içine bakıyoruz
            
            # Çağıran (Caller)
            caller_name, caller_class = get_method_details_safe(method)
            if not caller_name: continue

            # XREF_TO: Bu metod kimleri çağırmış?
            xrefs = []
            if hasattr(method, "get_xref_to"):
                xrefs = method.get_xref_to()
            
            for xref in xrefs:
                # Callee Çıkarma (Güvenli)
                callee = None
                if isinstance(xref, (list, tuple)):
                    if len(xref) > 1 and hasattr(xref[1], 'name'): callee = xref[1]
                    elif len(xref) > 0 and hasattr(xref[0], 'name'): callee = xref[0]
                else:
                    callee = xref
                
                if not callee: continue
                
                callee_name, callee_class = get_method_details_safe(callee)
                
                # HEDEF API KONTROLÜ
                matched_cat = None
                for cat, signatures in TARGET_APIS.items():
                    for sig in signatures:
                        if "->" in sig:
                            t_class, t_method = sig.split("->", 1)
                            t_class = normalize_class_name(t_class)
                            if callee_class == t_class and callee_name.startswith(t_method):
                                matched_cat = cat
                                break
                        else:
                            t_class = normalize_class_name(sig)
                            if callee_class == t_class:
                                matched_cat = cat
                                break
                    if matched_cat: break
                
                if matched_cat:
                    call_key = (matched_cat, caller_class, caller_name, callee_name)
                    if call_key in seen_calls: continue
                    seen_calls.add(call_key)
                    
                    total_hits += 1
                    
                    # Veri İşleme
                    results["api_inventory"][matched_cat] += 1
                    
                    ctx = get_inheritance_context(dx, caller_class)
                    if ctx in results["execution_context"]:
                        results["execution_context"][ctx] += 1
                        
                    if any(x in caller_name for x in ["onClick", "onTouch", "onItemClick"]):
                        results["trigger_types"]["user_triggered"] += 1
                    elif any(x in caller_name for x in ["onCreate", "onStart", "onReceive", "onBoot"]):
                        results["trigger_types"]["auto_triggered"] += 1
                        
                    if matched_cat == "scheduling_apis":
                        if "Alarm" in callee_class: results["scheduling_mechanisms"]["alarm_manager"] += 1
                        if "Handler" in callee_class: results["scheduling_mechanisms"]["handler_loop"] += 1
                        if "Job" in callee_class: results["scheduling_mechanisms"]["job_scheduler"] += 1
                    
                    if matched_cat == "dynamic_code":
                        if "loadLibrary" in callee_name: results["dynamic_features"]["jni_usage"] += 1
                        if "ClassLoader" in callee_class: results["dynamic_features"]["dynamic_loading"] += 1
                        if "reflect" in callee_class or "Class" in callee_class: results["dynamic_features"]["reflection"] += 1

        # JSON Kayıt
        if os.path.exists(json_path):
            with open(json_path, "r") as f: js_data = json.load(f)
            js_data["behavioral_structural_data"] = results
            with open(json_path, "w") as f: json.dump(js_data, f, indent=4, ensure_ascii=False)

        if total_hits > 0:
            return f"[HIT] {os.path.basename(apk_path)}: {total_hits} davranış"
        else:
            return f"[OK] {os.path.basename(apk_path)}: Temiz"

    except Exception as e:
        # Hata mesajını tam görelim artık
        return f"[ERROR] {os.path.basename(apk_path)}: {str(e)}"

# ========================================================
# 🚀 YÖNETİCİ
# ========================================================

def main():
    print(f"[*] FINAL SCANNER V5 (MANUEL MOD)")
    print(f"[*] İşlemci: {MAX_WORKERS} | Timeout: {TIMEOUT_SECONDS}sn")
    
    tasks = []
    print("[*] Görevler toplanıyor...")
    for root in ROOTS:
        if os.path.exists(root):
            for folder in os.scandir(root):
                if folder.is_dir():
                    json_p = os.path.join(folder.path, "summary.json")
                    if os.path.exists(json_p):
                        try:
                            with open(json_p) as f: meta = json.load(f)
                            sha256 = meta.get("sha256", "")
                            apk_name = meta.get("apk_name", "")
                            apk_full = os.path.join(APK_DIR, sha256 + ".apk")
                            if not os.path.exists(apk_full):
                                apk_full = os.path.join(APK_DIR, apk_name + ".apk")
                            if os.path.exists(apk_full):
                                tasks.append((json_p, apk_full))
                        except: pass

    print(f"[*] Toplam {len(tasks)} APK analiz edilecek.")
    
    with concurrent.futures.ProcessPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_apk = {executor.submit(analyze_apk_worker, task): task for task in tasks}
        
        completed = 0
        hits_count = 0
        
        for future in concurrent.futures.as_completed(future_to_apk):
            apk_info = future_to_apk[future]
            try:
                result = future.result(timeout=TIMEOUT_SECONDS)
                if "[HIT]" in result:
                    hits_count += 1
                    print(result)
                elif "[ERROR]" in result:
                    print(result)
            except concurrent.futures.TimeoutError:
                print(f"[TIMEOUT] {os.path.basename(apk_info[1])}")
            except Exception as e:
                print(f"[CRITICAL] {e}")
            
            completed += 1
            if completed % 10 == 0:
                print(f"    -> {completed}/{len(tasks)} tamamlandı. (Bulunan: {hits_count})")

    print("\n[✓] ANALİZ TAMAMLANDI.")

if __name__ == "__main__":
    multiprocessing.set_start_method("spawn", force=True)
    main()
