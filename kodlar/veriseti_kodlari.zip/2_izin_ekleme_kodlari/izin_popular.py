#!/usr/bin/env python3
import os
import json
import pandas as pd
import sys

# ========================================================
# AYARLAR
# ========================================================
CSV_PATH = "resmi_android_izin_duzeltilmis.csv"
ROOTS = ["/home/azureuser/dataset/Popular_result"]

def load_aosp_map_from_csv(csv_path):
    """
    CSV dosyasından izin haritasını oluşturur. 
    HİÇBİR DÖNÜŞÜM YAPMAZ. CSV'de ne yazıyorsa onu alır.
    """
    permission_map = {}
    
    if not os.path.exists(csv_path):
        print(f"[!] Hata: CSV dosyası bulunamadı: {csv_path}")
        sys.exit(1)

    try:
        df = pd.read_csv(csv_path)
        
        # MAPPING YOK! 
        # Sadece string temizliği (lowercase/strip) yapıyoruz ki eşleşme hatası olmasın.
        
        count = 0
        for index, row in df.iterrows():
            full_name = str(row['Tam_Deger']).strip()
            short_name = str(row['Izin_Adi']).strip()
            
            # CSV'deki değeri olduğu gibi al (küçük harfe çevir)
            raw_level = str(row['Koruma_Seviyesi']).strip().lower()
            
            # Eğer hücre boşsa veya nan ise 'unknown' yap
            if raw_level == "nan" or not raw_level:
                final_level = "unknown"
            else:
                final_level = raw_level
            
            # 1. Tam İsimle Kaydet
            if full_name and full_name != "nan":
                permission_map[full_name] = final_level
            
            # 2. Kısa İsimle Kaydet
            if short_name and short_name != "nan":
                permission_map[short_name] = final_level
            
            count += 1

        print(f"[+] CSV Yüklendi. {len(permission_map)} adet izin kuralı hafızaya alındı.")
        return permission_map

    except Exception as e:
        print(f"[!] CSV Okuma Hatası: {e}")
        sys.exit(1)

def determine_level_strict(perm_full_name, aosp_map):
    """
    Sadece CSV haritasına bakar. Bulamazsa 'unknown' döner.
    """
    # 1. Tam İsim Kontrolü
    if perm_full_name in aosp_map:
        return aosp_map[perm_full_name]
    
    # 2. Kısa İsim Kontrolü
    short_name = perm_full_name.split(".")[-1]
    if short_name in aosp_map:
        return aosp_map[short_name]
    
    # 3. Bulunamadıysa -> unknown
    return "unknown"

def strict_patch_dynamic(json_path, aosp_map):
    try:
        with open(json_path, "r") as f:
            data = json.load(f)
        
        perms = data["metadata"].get("permissions", [])
        new_details = {}
        
        # Sayaçları dinamik başlatıyoruz. Sabit anahtar (dangerous vb.) zorlamıyoruz.
        # CSV'den ne gelirse onu sayacak.
        new_counts = {}

        for p in perms:
            lvl = determine_level_strict(p, aosp_map)
            
            new_details[p] = lvl
            
            # Dinamik sayaç artırımı
            if lvl in new_counts:
                new_counts[lvl] += 1
            else:
                new_counts[lvl] = 1

        # JSON'ı güncelle
        data["metadata"]["permission_details"] = new_details
        data["metadata"]["risk_counts"] = new_counts

        with open(json_path, "w") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
            
    except Exception as e:
        print(f"[!] Dosya hatası: {json_path} -> {e}")

if __name__ == "__main__":
    # 1. Haritayı Yükle
    aosp_map = load_aosp_map_from_csv(CSV_PATH)
    
    print("[*] Strict Mode (CSV Birebir) Yamalama Başlatılıyor...")
    processed_count = 0
    
    for root in ROOTS:
        if os.path.exists(root):
            for folder in os.scandir(root):
                if folder.is_dir():
                    target = os.path.join(folder.path, "summary.json")
                    if os.path.exists(target):
                        strict_patch_dynamic(target, aosp_map)
                        processed_count += 1
                        if processed_count % 500 == 0:
                            print(f"    -> {processed_count} JSON güncellendi...")
    
    print(f"[✓] İşlem tamamlandı. Toplam {processed_count} APK verisi CSV'deki değerlerle güncellendi.")
